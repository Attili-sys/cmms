"""Outbound HTTP.

One place, so every call has a timeout. A request without one is how a pod hangs
and then fails its readiness probe for a reason nothing points at. Set a connect
timeout too — a host that never answers is the common case. The read timeout is for each
piece of the answer, not the whole call: a long download that keeps arriving is not cut off.
"""

import httpx

# The public API: what an app imports, and what this module's README documents.
__all__ = ["TIMEOUT", "client"]

TIMEOUT = httpx.Timeout(10.0, connect=5.0)


def client() -> httpx.Client:
    """A client for a call outside, with the platform's timeouts — `with client() as c: c.get(url)`."""
    return httpx.Client(timeout=TIMEOUT)
