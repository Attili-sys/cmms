"""Who may use this app — the route's `access` in score.yaml, checked on every request.

The platform signs people in (`auth: sso`) and says who they are (ajnkit/identity.py); this decides
whether that person may do what the request does:

    read    view it — GET, HEAD, OPTIONS — and ask: a POST to a route marked `@access.asks`
    write   change things — any other method. The same people as read when score.yaml lists no write
    deny    never, whatever read and write say

A route that only asks — a chat's question, a search sent as a form — changes nothing, so those who
may view the app may send it: mark it, and keep it to that. Anything it stores is a change, and
belongs on a route of its own (#98):

    @router.post("/ask")
    @access.asks
    def ask(q: chat.Ask): ...

An entry is an email, or a group name exactly as the sign-in carries it: an Entra group, or a Canvas
team's `canvas-<team>-owners` / `canvas-<team>-members` (`canvas share team`). No `access` block: anyone
who signs in. It runs as middleware (ajnkit.web.platform installs it), so no route can forget it; the readiness probe is
let through because the kubelet calls it directly, with no sign-in. The same middleware refuses a
write another site sent, and asks browsers not to frame the app — ajnkit/origin.py, for every app. Finer rules — /admin for two
groups — are ajnkit/rbac.py's, on the route that needs them, matched by `matches` (ajnkit.identity).
"""

import inspect
from html import escape

from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

from ajnkit import _routes, docs, origin, rbac
from ajnkit.identity import Caller, caller, matches
from ajnkit.logger import log
from ajnkit.settings import envs

# The public API: what an app imports, and what this module's README documents.
__all__ = ["DOCS", "HEALTH", "NoSockets", "allowed", "asks", "enforce", "invalid", "matches"]

READ = origin.SAFE                       # what reads: the same methods the cross-site check lets by
HEALTH = "/healthz"  # must match route.params.path in score.yaml, like views.healthz
# FastAPI's docs pages (src/app.py), which the platform opens without the sign-in when score.yaml
# says `docs: public` — so they come with no caller, and must not meet the read/write/deny check.
# The page's own files (ajnkit/docs.py) open with it.
DOCS = {"/api/docs", "/api/docs/oauth2-redirect", "/api/redoc", "/api/openapi.json",
        *(f"/static/platform/swagger/{f}" for f in ("swagger-ui.css", "swagger-ui-bundle.js", "init.js"))}


# The functions marked `asks`. A request is an ask only when a marked route is the ONE route that can
# answer it (ajnkit._routes): a writing route on the same path — registered first, it is what FastAPI
# runs — would otherwise be sent what only readers sent.
_ASKS: set = set()
_SAID: set = set()      # the marked functions already warned about — never paths, which a caller chooses


def asks(fn):
    """Mark a POST route as a question that changes nothing: `read` may send it, not only `write`."""
    _ASKS.add(inspect.unwrap(fn))
    return fn


def _asks(request: Request) -> bool:
    """Whether this request is a POST that only a route marked `asks` can answer."""
    if request.method.upper() != "POST" or not _ASKS:
        return False
    answers = _routes.answering(request, "POST")
    marked = [inspect.unwrap(a.endpoint) for a in answers if a.endpoint is not None and inspect.unwrap(a.endpoint) in _ASKS]
    if len(answers) > 1 and (new := [fn for fn in marked if fn not in _SAID]):
        _SAID.update(new)
        log.warning(f"@access.asks {', '.join(fn.__name__ for fn in new)}: another route answers the same "
                    "POST — give it a path of its own; until then only `write` may send it")
    return len(answers) == 1 and bool(marked)


def allowed(who: Caller, method: str, rules: dict) -> bool:
    """Whether `who` may send `method` by score.yaml's access: `deny` first, then `read` for GET, HEAD
    and OPTIONS, and `write` (or `read` when there is none) for the rest."""
    if matches(who, rules.get("deny", [])):
        return False
    read, write = rules.get("read"), rules.get("write", rules.get("read"))
    if method.upper() in READ:
        # Writers can always read: a list of who may change things is also a list of who may look.
        return read is None or matches(who, read) or (write is not None and matches(who, write))
    return write is None or matches(who, write)


def _refused(who: Caller) -> HTMLResponse:
    return HTMLResponse(
        "<!doctype html><title>No access</title>"
        "<main style='font-family:system-ui;max-width:32rem;margin:4rem auto;line-height:1.5'>"
        "<h1 style='font-size:1.4rem'>You do not have access to this app</h1>"
        f"<p>You are signed in as <b>{escape(who.email or 'unknown')}</b>. "
        "Ask the app's owners to add you or one of your groups.</p></main>",
        status_code=403,
    )


ERRORS_MAX, PART_MAX = 10, 100           # what a 422 names: the first errors, each part of a place cut


def _said(v):
    """A place or a message as the answer can carry it: cut, and half an emoji made whole (#113)."""
    return v[:PART_MAX].encode("utf-8", "replace").decode() if isinstance(v, str) else v


async def invalid(request: Request, exc: RequestValidationError):
    """The 422 for a body, query or path the route cannot read: where and what, never the input.
    FastAPI's own writes the whole input back — a 9 MiB body answered with 9 MiB (#120) — and its
    `ctx` can hold it too. ajnkit.web.platform installs it unless the app has its own."""
    errors = [{"loc": [_said(x) for x in e.get("loc", ())], "msg": _said(str(e.get("msg", ""))),
               "type": _said(str(e.get("type", "")))} for e in exc.errors()[:ERRORS_MAX]]
    return JSONResponse({"detail": errors}, status_code=422)


async def enforce(request: Request, call_next):
    """The platform's checks on every request, as middleware — a body over the cap, a write another
    site sent, score.yaml's access — and the security headers on every answer. ajnkit.web.platform
    installs it; never install a second."""
    _routes.path(request)                 # read now, before routing changes root_path
    if origin.too_large(request):
        return origin.harden(origin.refused_size(request))
    if origin.cross_site(request):
        return origin.harden(origin.refused())
    over = origin.cap(request)
    origin.fresh(request)
    try:
        response = await _admit(request, call_next)
    except rbac.Forbidden:
        # A rule refused (@require, ajnkit/rbac.py): a 403 wherever it was raised — JSON for /api,
        # which a client or another app reads, the same page as `access` for a person's browser.
        who = caller(request.headers)
        if _routes.path(request).startswith("/api/"):
            return origin.harden(JSONResponse({"detail": f"{who.email or 'nobody signed in'} may not do this"},
                                              status_code=403))
        return origin.harden(_refused(who))
    except Exception as e:  # noqa: BLE001 — every crash: logged with its traceback, then answered
        if isinstance(e.__cause__ or e.__context__, RequestValidationError):
            # An app's own 422 that writes the input back, and half an emoji cannot be written (#113):
            # it failed while refusing a body, so the refusal still goes out — without the echo. The
            # platform's own (`invalid`) never fails so.
            return origin.harden(JSONResponse({"detail": "the request's body could not be read"}, status_code=422))
        # The app raised: Starlette's own 500 would go out without the headers every other answer has
        # (#106). The same plain 500, hardened — and the traceback in the log, as before.
        if not over():
            log.exception("unhandled error on %s %s", request.method, _routes.path(request))
        response = PlainTextResponse("Internal Server Error", status_code=500)
    # A body over the cap is a 413, whatever its reader made of the refused read (origin.cap).
    return origin.harden(origin.refused_size(request) if over() else origin.cached(request, response))


class NoSockets:
    """Refuses every WebSocket: an `http` middleware — enforce — never sees one, so neither score.yaml's
    access nor the cross-site check would stand in front of it, and the platform provisions none
    (`canvas validate`). ajnkit.web.platform installs it."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})     # before accepting: a 403 to the browser
            return
        await self.app(scope, receive, send)


async def _admit(request: Request, call_next):
    at = _routes.path(request)
    if envs.PLATFORM_AUTH != "sso" or not envs.PLATFORM_ACCESS or at == HEALTH:
        return docs.answer(request) or await call_next(request)
    if envs.PLATFORM_DOCS == "public" and at in DOCS:
        return docs.answer(request) or await call_next(request)
    who = caller(request.headers)
    # Whether it only asks is looked at only for someone who may read: nobody else gets that far.
    may = allowed(who, request.method, envs.PLATFORM_ACCESS) or (allowed(who, "GET", envs.PLATFORM_ACCESS) and _asks(request))
    if who.email is None or not may:
        return _refused(who)
    return docs.answer(request) or await call_next(request)
