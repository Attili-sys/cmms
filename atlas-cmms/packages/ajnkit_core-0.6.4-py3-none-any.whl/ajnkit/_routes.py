"""Which of the app's routes can answer a request, asked before the app routes it — and the path they
match. The platform's own (access.py, origin.py, docs.py); no app imports it.

access.enforce decides before routing, so two of its checks need to know what will answer: an ask
(`@access.asks`) is a reader's only when the marked route is the one route that can answer it, and a
body may be a form's size only when what answers reads a form. Every route counts, not only the first
to match: FastAPI answers with the first registered, and an app's routers are included in whatever
order its src/app.py says. A route this cannot see into — a mount, a Host — counts as one that answers
everything, and is never an ask or a form.
"""

from collections.abc import Callable
from dataclasses import dataclass
from functools import cache
from re import Pattern
from typing import Any

from fastapi import params
from fastapi.dependencies.utils import get_dependant
from starlette.requests import HTTPConnection
from starlette.routing import Mount, compile_path


@dataclass(frozen=True)
class Answer:
    endpoint: Callable[..., Any] | None   # the view, or None for what is not seen into
    form: bool                            # it reads a form or a file


_ANYTHING = Answer(None, False)


@cache
def _pattern(path: str) -> Pattern:
    return compile_path(path)[0]


def path(request: HTTPConnection) -> str:
    """The path the router matches — decoded, so `%3F` is a `?` in it, and without the root path.
    Never `request.url.path`: rebuilt as a URL, it ends at a decoded `?` or `#`, and
    `/healthz%3F/secret` would read as `/healthz`. Kept from its first reading — access.enforce's,
    before routing: a mount adds its own prefix to root_path as it routes."""
    scope = request.scope
    if "ajnkit.path" not in scope:
        p, root = scope["path"], scope.get("root_path", "")
        scope["ajnkit.path"] = p[len(root):] if root and p.startswith(root) else p
    return scope["ajnkit.path"]


def _reads_form(dependant) -> bool:
    """Whether the route — or a dependency of it — takes a form field or a file."""
    return (any(isinstance(p.field_info, params.Form) for p in dependant.body_params)
            or any(_reads_form(d) for d in dependant.dependencies))


def _included_form(context) -> bool:
    """Whether a dependency given to include_router() takes a form: FastAPI keeps those on the
    included router, not on its routes' dependant."""
    return any(_reads_form(get_dependant(path="", call=d.dependency))
               for d in getattr(context, "dependencies", None) or [] if getattr(d, "dependency", None))


def _walk(routes, prefix: str = "", form: bool = False):
    """(its pattern, its methods, its Answer, its full path) for every route, into included routers."""
    for r in routes:
        if (inner := getattr(r, "original_router", None)) is not None:     # FastAPI keeps an included router whole
            yield from _walk(inner.routes, prefix + r.include_context.prefix, form or _included_form(r.include_context))
        elif isinstance(r, Mount):
            yield _pattern(prefix + r.path.rstrip("/") + "/{rest:path}"), None, _ANYTHING, None
        elif (route_path := getattr(r, "path", None)) is not None and hasattr(r, "endpoint"):
            dependant = getattr(r, "dependant", None)
            reads = form or (dependant is not None and _reads_form(dependant))
            yield _pattern(prefix + route_path), getattr(r, "methods", None), Answer(r.endpoint, reads), prefix + route_path
        else:                                                               # a Host, or a route of its own kind
            yield _pattern("/{rest:path}"), None, _ANYTHING, None


def gets(app) -> list[str]:
    """Every GET route's full path with no parameter in it — what can be opened as it is (ajnkit.smoke)."""
    return [p for _, methods, _, p in _walk(app.router.routes) if p and "GET" in (methods or ()) and "{" not in p]


def answering(request: HTTPConnection, method: str) -> list[Answer]:
    """Every route of the app that matches this request's path for `method` — worked out once a
    request: the body cap asks up to three times."""
    key = f"ajnkit.answering.{method}"
    if key not in request.scope:
        at = path(request)
        request.scope[key] = [a for pattern, methods, a, _ in _walk(request.app.router.routes)
                              if (methods is None or method in methods) and pattern.match(at)]
    return request.scope[key]
