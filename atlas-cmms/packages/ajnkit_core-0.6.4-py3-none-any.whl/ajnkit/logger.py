"""Structured logging.

JSON to **stdout** — Alloy ships it to Loki, already labelled with team, app and
owner by the platform. Never write a log file: the filesystem is read-only, and
a file nothing collects is a log nobody reads.
"""

import json
import logging
import sys

# The public API: what an app imports, and what this module's README documents.
__all__ = ["log"]


# What every LogRecord carries; anything else on one came from `extra={…}`.
_STANDARD = set(vars(logging.LogRecord("", 0, "", 0, "", None, None))) | {"message", "asctime"}


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        line = {k: v for k, v in vars(record).items() if k not in _STANDARD}
        line |= {
            "level": record.levelname.lower(),
            "msg": record.getMessage(),
            "logger": record.name,
        }
        # log.exception's whole point: without it a crash is logged as one line and no cause (#108).
        if record.exc_info:
            line["exc"] = self.formatException(record.exc_info)
        return json.dumps(line, default=str)


handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())

log = logging.getLogger("app")
log.setLevel(logging.INFO)
log.addHandler(handler)
