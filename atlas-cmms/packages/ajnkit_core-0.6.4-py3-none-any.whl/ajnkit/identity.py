"""Who is calling — read from platform-injected headers.

DO NOT IMPLEMENT OIDC HERE. When score.yaml sets `route.params.auth: sso`, the platform
signs the person in (Authentik) before the request reaches this container and adds the
X-authentik-* headers below — replacing any the caller sent. App-side auth is duplicated
work that drifts from the platform's, and the `add-auth` skill says so explicitly.

With `auth: none` (the default) these headers are absent — and, critically, **forgeable**:
without the platform's sign-in in the path, a caller can send them itself. Reading them for
display or logging is fine; authorising on them is not. Use ajnkit/rbac.py, which refuses
unless envs.PLATFORM_AUTH == "sso".

Treat a missing user as anonymous, never as an error.
"""

from dataclasses import dataclass

# The public API: what an app imports, and what this module's README documents.
__all__ = ["Caller", "caller", "matches"]


@dataclass(frozen=True)
class Caller:
    """Who is calling, as the platform's sign-in says: their email, name and Entra groups. All empty
    for nobody signed in — and, under `auth: none`, forgeable."""

    email: str | None
    name: str | None
    groups: tuple[str, ...]


def _text(value: str) -> str:
    """A header as Authentik wrote it. HTTP reads header bytes as Latin-1, and Authentik sends UTF-8,
    so an Entra group like "AI Engineering – Standards" arrives garbled unless read back."""
    try:
        return value.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return value


def caller(headers) -> Caller:
    """Who sent the request with these headers — `caller(request.headers)`."""
    # Authentik separates groups with `|` — a group name may contain a comma.
    return Caller(
        email=_text(headers.get("X-authentik-email") or "") or None,
        name=_text(headers.get("X-authentik-name") or "") or None,
        groups=tuple(g for g in _text(headers.get("X-authentik-groups", "")).split("|") if g),
    )


def matches(who: Caller, entries: list[str]) -> bool:
    """Whether `who` is one of `entries` — an email (any case) or an Entra group, as score.yaml's
    `access` lists them."""
    email = (who.email or "").lower()
    return any(e.lower() == email if "@" in e else e in who.groups for e in entries)
