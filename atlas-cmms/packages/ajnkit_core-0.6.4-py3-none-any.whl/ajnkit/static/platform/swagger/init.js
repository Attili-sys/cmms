// The API's docs page (ajnkit.docs), from a file: the platform's policy runs no inline script.
// swagger-ui-dist 5.33.1 (Apache-2.0, LICENSE beside it), VENDORED like htmx — never from a CDN, whose
// script would run on the app's own address as whoever opened the docs.
const ui = document.getElementById("swagger-ui");
window.ui = SwaggerUIBundle({
  url: ui.dataset.url, dom_id: "#swagger-ui", layout: "BaseLayout",
  presets: [SwaggerUIBundle.presets.apis, SwaggerUIBundle.SwaggerUIStandalonePreset],
  deepLinking: true, showExtensions: true, showCommonExtensions: true,
});
