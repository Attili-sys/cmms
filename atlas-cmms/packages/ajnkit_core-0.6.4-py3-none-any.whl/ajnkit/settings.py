"""What the platform's code reads of the app's settings: the app's own `src/envs.py` — the one place an
app reads them (its AGENTS.md), so a test that sets one there sets it for the platform too. Read at
each use, never kept: a test or `canvas llm env` sets them after import.

    from ajnkit.settings import envs
    envs.PLATFORM_AUTH

Without a `src/envs.py` (the package's own tests), the environment, read as an app's envs.py reads it.
"""

import json
import os
from pathlib import Path
from typing import Any

# The public API: what an app imports, and what this module's README documents.
__all__ = ["envs", "get"]

_FROM_ENVIRON = {
    "PLATFORM_AUTH": lambda: os.environ.get("PLATFORM_AUTH", "none"),
    "PLATFORM_ACCESS": lambda: json.loads(os.environ.get("PLATFORM_ACCESS") or "{}"),
    "PLATFORM_DOCS": lambda: os.environ.get("PLATFORM_DOCS", "private"),
    "DATABASE_URL": lambda: (os.environ.get("DATABASE_URL") or "").replace("postgresql://", "postgresql+psycopg://", 1) or None,
    "DATA_DIR": lambda: Path(os.environ.get("DATA_DIR", "data")),
}


def _app():
    try:
        from src import envs  # pyright: ignore[reportMissingImports] — the app's own package
    except ImportError:
        return None
    return envs


class _Envs:
    """`src.envs` itself, read and written through: a test's `monkeypatch.setattr(access.envs, …)` sets
    the app's setting, as it did when `access.envs` was that module — and is undone there."""

    def __getattr__(self, name: str) -> Any:
        if (envs := _app()) is not None:
            return getattr(envs, name)
        if name in _FROM_ENVIRON:
            return _FROM_ENVIRON[name]()
        if name.isupper():
            return os.environ.get(name) or None
        raise AttributeError(name)

    def __setattr__(self, name: str, value) -> None:
        if (envs := _app()) is None:
            raise AttributeError(f"no src/envs.py to set {name} in")
        setattr(envs, name, value)

    def __delattr__(self, name: str) -> None:
        if (envs := _app()) is not None:
            delattr(envs, name)


envs = _Envs()


def get(name: str) -> str | None:
    """One of the app's settings, or None when it is not set (empty is not set)."""
    return getattr(envs, name, None) or None
