"""A live preview's marks: which template line made each element, so a person can point at one and say "change this"
(Canvas Studio, plans/studio-phase4-click-to-change.md).

Only when the app starts with `PLATFORM_PREVIEW=1`, which Studio's lab sets for the dev server it runs and nothing else
does: then every HTML start tag in the app's own templates gets `data-src="<template>:<line>"`. The platform's own templates
(`platform/…`) are not marked, so a click on one of its components lands on the app's element around it. A deployed app has
no flag, no attribute and no code path here.

A platform component (a macro of `platform/ui.html`: the page header, a button, a table) is not marked inside, but the place the app calls
it is: an HTML comment `<!--ajnkit:src <template>:<line>-->` goes before the call, so the picker can say "this heading comes from
`index.html` line 4" for an element the app did not write by hand. A comment changes nothing a person sees.

The scan reads the template source, not the output: it passes over what Jinja owns (`{{ }}`, `{% %}`, `{# #}`, `{% raw %}`),
comments, `<script>` and `<style>`, and inside a tag over quoted values, so it adds one attribute after the tag's name and
changes nothing else — no line is added or removed, so Jinja's own line numbers in an error stay true."""

import os
import re

from jinja2 import Environment
from jinja2.ext import Extension

__all__ = ["Marks", "install", "mark", "on"]

_TOKEN = re.compile(r"\{#|\{\{|\{%|<!--|<[A-Za-z][A-Za-z0-9-]*")
_NEVER = {"html", "head", "meta", "link", "title", "base", "noscript", "template"}     # nothing a person points at
_RAW_END = re.compile(r"\{%-?\s*endraw\s*-?%\}")
_CLOSE = {"{#": "#}", "{{": "}}", "{%": "%}"}
_FROM = re.compile(r"""\{%-?\s*from\s+["']platform/[\w./-]+["']\s+import\s+(.+?)\s*-?%\}""", re.DOTALL)
_AS = re.compile(r"""\{%-?\s*import\s+["']platform/[\w./-]+["']\s+as\s+(\w+)\s*-?%\}""")
_CALL = re.compile(r"(?:(\w+)\.)?(\w+)\s*\(")
_BLOCK_CALL = re.compile(r"\s*-?\s*call\b(?:\([^)]*\))?\s+(?:(\w+)\.)?(\w+)\s*\(")


def on() -> bool:
    return os.environ.get("PLATFORM_PREVIEW") == "1"


def _after(source: str, closer: str, i: int) -> int:
    j = source.find(closer, i)
    return len(source) if j < 0 else j + len(closer)


def _end_of_tag(source: str, i: int) -> int:
    """Where the start tag that began before `i` ends: past its `>`, over quoted values and over Jinja's constructs."""
    quote, n = "", len(source)
    while i < n:
        two = source[i:i + 2]
        if two in _CLOSE:
            i = _after(source, _CLOSE[two], i + 2)
            continue
        ch = source[i]
        if quote:
            quote = "" if ch == quote else quote
        elif ch in "\"'":
            quote = ch
        elif ch == ">":
            return i + 1
        i += 1
    return n


def _components(source: str) -> tuple[set[str], set[str]]:
    """The macros this template takes from the platform's own (`{% from "platform/ui.html" import card, button as b %}`) and
    the names it gives the module (`{% import "platform/ui.html" as ui %}`)."""
    names = {part.split(" as ")[-1].strip() for m in _FROM.finditer(source) for part in m.group(1).split(",") if part.strip()}
    return names, {m.group(1) for m in _AS.finditer(source)}


def mark(source: str, name: str) -> str:
    """`source` with `data-src="name:line"` after the name of each start tag a person could point at, and a comment with the
    same place before each call of a platform component."""
    out, copied, i, line, seen = [], 0, 0, 1, 0
    names, aliases = _components(source)
    while (m := _TOKEN.search(source, i)):
        t = m.group(0)
        if t in _CLOSE:
            ahead = source[m.end():m.end() + 90]
            call = (_CALL.match(ahead.lstrip("-+ ")) if t == "{{" else _BLOCK_CALL.match(ahead) if t == "{%" else None)
            if call and ((call.group(1) in aliases) or (call.group(1) is None and call.group(2) in names)):
                line += source.count("\n", seen, m.start())
                seen = m.start()
                out.append(source[copied:m.start()])
                out.append(f"<!--ajnkit:src {name}:{line}-->")
                copied = m.start()
            if t == "{%" and re.match(r"-?\s*raw\b", source[m.end():m.end() + 12]):
                raw = _RAW_END.search(source, m.end())
                i = raw.end() if raw else len(source)
            else:
                i = _after(source, _CLOSE[t], m.end())
            continue
        if t == "<!--":
            i = _after(source, "-->", m.end())
            continue
        tag = t[1:].lower()
        if tag in ("script", "style"):
            i = _after(source, f"</{tag}", m.end())
            continue
        i = _end_of_tag(source, m.end())
        if tag in _NEVER:
            continue
        line += source.count("\n", seen, m.start())
        seen = m.start()
        out.append(source[copied:m.end()])
        out.append(f' data-src="{name}:{line}"')
        copied = m.end()
    out.append(source[copied:])
    return "".join(out)


class Marks(Extension):
    """Jinja's hook on a template's source, before it is compiled."""

    def preprocess(self, source: str, name: str | None, filename: str | None = None) -> str:
        return source if not name or name.startswith("platform/") else mark(source, name)


def install(env: Environment) -> bool:
    """Mark the app's templates when this is a preview; says whether it did. `preview` is then a template global (the shell
    puts `data-preview` on the page, and the platform's script offers the picker to the frame)."""
    if not on():
        return False
    env.add_extension(Marks)
    env.globals["preview"] = True
    return True
