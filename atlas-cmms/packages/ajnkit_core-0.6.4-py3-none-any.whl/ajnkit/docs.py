"""The API's docs page — /api/docs — drawn from files the app serves itself.

THE PLATFORM'S (ajnkit; `canvas app update` brings the next version), answered from access.enforce, after the access check.

FastAPI's own page loads Swagger UI from a CDN, with an inline script to start it. The platform's
policy (ajnkit/origin.py) runs neither, and should not: a script from another site, on the app's own
address, acts as whoever opens the docs. So the same Swagger UI is vendored under
static/platform/swagger/ and drawn here. ReDoc's page sends the reader here, rather than a second
bundle. An app that hid its docs (`docs_url=None` in src/app.py) is left as it chose.
"""

from html import escape

from fastapi import Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from ajnkit import _routes
from ajnkit.web import about, asset, favicon

# The public API: what an app imports, and what this module's README documents.
__all__ = ["PAGE", "REDOC", "answer"]

PAGE = "/api/docs"
REDOC = "/api/redoc"


def answer(request: Request) -> Response | None:
    """The docs page for this request, or None to let the app answer it."""
    app = request.app
    if request.method not in ("GET", "HEAD") or app.docs_url != PAGE or not app.openapi_url:
        return None
    at = _routes.path(request)
    if at == REDOC and app.redoc_url == REDOC:
        return RedirectResponse(PAGE, status_code=307)
    if at != PAGE:
        return None
    return HTMLResponse(
        "<!doctype html><html><head><meta charset='utf-8'>"
        f"<title>{escape(about()['title'] or 'API')} — API</title>"
        # The app's tab icon, as its pages name it — else the browser asks for /favicon.ico, a 404 (#107).
        f"<link rel='icon' href='{escape(favicon())}'>"
        f"<link rel='stylesheet' href='{asset('platform/swagger/swagger-ui.css')}'></head>"
        f"<body><div id='swagger-ui' data-url='{escape(app.openapi_url)}'></div>"
        f"<script src='{asset('platform/swagger/swagger-ui-bundle.js')}'></script>"
        f"<script src='{asset('platform/swagger/init.js')}'></script></body></html>"
    )
