"""Database connection and session handling.

Connects with `envs.DATABASE_URL`, present only when score.yaml declares the
`postgres` resource.

DO NOT CREATE TABLES HERE. No `create_all`, no auto-migrate, no
`CREATE TABLE IF NOT EXISTS`. Schema comes from `canvas db revision` and is
applied before the app starts.

One instance, one pod, no replica, no backup:
  - a restart is downtime, and a spot eviction moves the pod. Connections drop
    for 30-60s: `pool_pre_ping` is here; a retry, where a write must not be lost, is the app's.
  - keep the pool small.
"""

from collections.abc import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from ajnkit.settings import envs

# The public API: what an app imports, and what this module's README documents.
__all__ = ["engine", "session"]

engine = (
    create_engine(
        envs.DATABASE_URL,
        pool_size=5,
        max_overflow=5,
        pool_pre_ping=True,
        # A query past 15 s is a missing index or a model's runaway SQL: it ends, rather than holding
        # one of the few connections while every page waits behind it. A database that does not
        # answer fails the request in 5 s, so it can be retried.
        connect_args={"connect_timeout": 5, "options": "-c statement_timeout=15000"},
    )
    if envs.DATABASE_URL
    else None
)

SessionLocal = sessionmaker(bind=engine, expire_on_commit=False) if engine else None


def session() -> Iterator[Session]:
    """FastAPI dependency: `db: Annotated[Session, Depends(session)]` — Annotated, as FastAPI
    recommends; a plain `= Depends(session)` default is what ruff's B008 refuses."""
    if SessionLocal is None:
        raise RuntimeError("no `postgres` resource declared in score.yaml")
    with SessionLocal() as s:
        yield s
