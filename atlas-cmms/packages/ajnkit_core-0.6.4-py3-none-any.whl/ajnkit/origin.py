"""Requests another site makes your browser send, and pages another site frames.

THE PLATFORM'S (ajnkit; `canvas app update` brings the next version), run from access.enforce on every request.

Every app is `<app>--<team>.<base>`: one SITE with every other app and the portal. So the browser's
SameSite rules do not stop a page in one team's app from submitting a form to another team's app:
the visitor's sign-in goes with it, and the write happens as them. Nor does anything stop one app
framing another to steer a click. This refuses a write that a browser says came from elsewhere, tells
browsers not to frame the app, and lets a page run only the app's own script files (POLICY). And a
request larger than the app reads (FORM_MAX, BODY_MAX) is refused at the same door.

A request with neither header is not a browser's — a script, a webhook, the tests — and is let
through: there is no visitor's sign-in for another site to borrow.
"""

import os
from urllib.parse import urlsplit

from fastapi import HTTPException, Request
from fastapi.responses import PlainTextResponse, Response

from ajnkit import _routes

# The public API: what an app imports, and what this module's README documents.
__all__ = ["BODY_MAX", "FORM_MAX", "HEADERS", "POLICY", "cached", "cap", "cross_site", "framer", "fresh", "harden", "refused", "refused_size", "too_large"]

SAFE = {"GET", "HEAD", "OPTIONS"}

# Script only from the app's own files — no inline script, no handler attribute, no eval, nothing
# from another site — so text a person or a model wrote that slips into a page cannot run. Styles may
# be inline (`style=` attributes); a style cannot act as the visitor. No form-action: a post whose
# sign-in has lapsed is sent on to the sign-in site, and the browser would refuse that redirect.
POLICY = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
          "img-src 'self' data: blob:; font-src 'self' data:; media-src 'self' data: blob:; "
          "connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")

HEADERS = {
    "Content-Security-Policy": POLICY,
    "X-Frame-Options": "DENY",
    "X-Content-Type-Options": "nosniff",
    # A page this app opens from another app, or that opens it, gets no handle on its window.
    "Cross-Origin-Opener-Policy": "same-origin",
}


def cross_site(request: Request) -> bool:
    if request.method.upper() in SAFE:
        return False
    # Sec-Fetch-Site is the browser's own answer; `none` is the person themselves (a bookmark).
    if fetched := request.headers.get("sec-fetch-site"):
        return fetched not in ("same-origin", "none")
    # Older browsers send only Origin. By host: behind the platform's TLS the app sees http.
    if origin := request.headers.get("origin"):
        return urlsplit(origin).netloc != request.headers.get("host", "")
    return False


# The largest request the app reads. A form with files: an upload (media.MAX_BYTES, 250 MiB) and the
# rest of the form, for a route that takes one — its files wait in /tmp, a disk on the platform, not memory. Any other body is read
# into memory whole, so no more than Next's proxy reads (origin.ts). Here, not at Traefik: its
# buffering would hold every answer too, and an LLM's streamed tokens would arrive all at once.
FORM_MAX = 256 << 20
BODY_MAX = 10 << 20


def _most(request: Request) -> int:
    """A form's cap only where what answers reads a form — every route that matches, as it is not
    known yet which one will: the Content-Type is the sender's to choose, and a JSON route sent
    `multipart/form-data` reads its body into memory all the same."""
    multipart = request.headers.get("content-type", "").lower().startswith("multipart/form-data")
    if not multipart:
        return BODY_MAX
    answers = _routes.answering(request, request.method.upper())
    return FORM_MAX if answers and all(a.form for a in answers) else BODY_MAX


def too_large(request: Request) -> bool:
    """A body whose Content-Length says it is over the cap — refused before a byte is read."""
    length = request.headers.get("content-length", "")
    return length.isdigit() and int(length) > _most(request)


def cap(request: Request):
    """Count the body as it arrives, for whoever reads it: Content-Length can be absent (chunked) or
    wrong (#109). Over the cap, the read raises — and what is returned says so: through Starlette's
    middleware that raise reaches the app as a crash, or FastAPI's parser makes it a 400, so the caller
    answers the 413 itself. Starlette's middleware reads `request._receive`, so that is what is wrapped."""
    most, receive, seen = _most(request), request._receive, 0

    async def counted():
        nonlocal seen
        message = await receive()
        seen += len(message.get("body", b""))
        if seen > most:
            raise HTTPException(413)
        return message

    request._receive = counted
    return lambda: seen > most


def refused_size(request: Request) -> Response:
    return PlainTextResponse(f"Refused: more than {_most(request) >> 20} MB in one request.\n", status_code=413)


def refused() -> Response:
    return PlainTextResponse("Refused: this request was sent from another site.\n", status_code=403)


IMMUTABLE = "public, max-age=31536000, immutable"


def fresh(request: Request) -> None:
    """An unversioned static file is sent whole, never a 304: the If-None-Match or If-Modified-Since a
    browser kept for it came from the 1980 date buildpacks give every file, and its size, so a changed
    file of the same size matched them for ever (canvas#208). They are dropped from the request before
    any static mount reads it — `cached` sends no new ones. A versioned one (`?v=`) keeps them."""
    if _routes.path(request).startswith("/static/") and not request.query_params.get("v"):
        request.scope["headers"] = [(k, v) for k, v in request.scope["headers"]
                                    if k not in (b"if-none-match", b"if-modified-since")]


def cached(request: Request, response: Response) -> Response:
    """How long a browser keeps a static file (#120). One by asset()'s URL — `?v=` a hash of the file,
    a new URL when it changes — for a year, never asked again. Any other is asked each time, with
    no ETag or Last-Modified: built from the 1980 date buildpacks give every file, they would call a
    changed file of the same size unchanged."""
    if _routes.path(request).startswith("/static/") and response.status_code == 200:
        if request.query_params.get("v"):
            response.headers["Cache-Control"] = IMMUTABLE
        else:
            response.headers["Cache-Control"] = "no-cache"
            for stale in ("etag", "last-modified"):
                if stale in response.headers:
                    del response.headers[stale]
    return response


def framer() -> str | None:
    """The one site that may frame the app's pages: the portal, once deployed — Canvas Studio shows the
    app it is building beside the conversation (ADR-47). The app chart's PLATFORM_PORTAL_URL, read at
    each call; https only. None elsewhere: on your computer nothing frames the app."""
    url = urlsplit(os.environ.get("PLATFORM_PORTAL_URL", ""))
    return f"https://{url.netloc}" if url.scheme == "https" and url.netloc else None


def harden(response: Response) -> Response:
    # setdefault: a page that sets its own policy keeps it (ajnkit/media.py does) — but never framed.
    for k, v in HEADERS.items():
        response.headers.setdefault(k, v)
    csp = response.headers["Content-Security-Policy"]
    if "frame-ancestors" not in csp:
        response.headers["Content-Security-Policy"] = f"{csp}; frame-ancestors 'none'"
    elif csp == POLICY and (portal := framer()):
        # The platform's own policy only: a page with its own (an upload) stays unframeable.
        response.headers["Content-Security-Policy"] = POLICY.replace("frame-ancestors 'none'", f"frame-ancestors {portal}")
        del response.headers["X-Frame-Options"]
    return response
