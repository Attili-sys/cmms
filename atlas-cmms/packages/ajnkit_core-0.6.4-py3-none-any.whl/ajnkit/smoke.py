"""Whether the app's pages open, checked by the app itself once it is up — a pod can pass /healthz while
every page fails (Canvas Studio's evaluation, 2026-10-10: its own template loader, a 500 on every page).

When deployed (PLATFORM_PORTAL_URL is set), `start(app)` — called by ajnkit.web.platform — waits for
/healthz, then opens each page once over 127.0.0.1, through the server and every check a request
meets: each GET route with no parameter in its path, as a member, and each page src/nav.py gives a
rule, as someone that rule and `access.read` both let in; a 401/403 is listed as `refused`, not counted as open. The identity it sends never leaves the pod: it is the app asking
itself. One log line a page, then the summary `canvas deploy` and Studio read (canvas.domain.smoke):

    {"msg": "smoke", "canvas_smoke": {"done": true, "ok": 7, "failed": [["/results", 500]]}}

PLATFORM_SMOKE=0 turns it off. GET only, once per start; a page that writes on GET is the app's bug."""

import threading
import time

import httpx

from ajnkit import _routes
from ajnkit.logger import log
from ajnkit.settings import envs

__all__ = ["start"]

_WAIT = 90                 # seconds for /healthz to answer before giving up (the server is not up)
_PAGE = 20                 # seconds a page may take
_MAX = 40                  # pages opened at most — the menu's first, and the summary names what it left out
_TOTAL = 120               # seconds for all of them: past it the rest is named, not waited for
_SKIP = ("/healthz", "/static", "/docs", "/redoc", "/openapi.json", "/api/docs", "/api/redoc", "/api/openapi.json", "/favicon")
_NOBODY = "canvas-smoke@canvas.invalid"


def _identity(*entries: str | None) -> dict[str, str]:
    """Who to be so that every entry lets this person in: score.yaml's emails are one person's (the
    first), its groups are all of the person's. With no entry, someone signed in and in no group."""
    given = [e for e in entries if e]
    email = next((e for e in given if "@" in e), _NOBODY)
    groups = "|".join(e for e in given if "@" not in e)
    return {"X-authentik-email": email, "X-authentik-name": "Canvas page check", **({"X-authentik-groups": groups} if groups else {})}


def _first(entries) -> str | None:
    return next(iter(entries or []), None)


def _visits(app) -> list[tuple[str, dict[str, str]]]:
    """(path, headers) for every page to open: the parameterless GETs as a reader, each rule's page as one who
    passes `access.read` AND the rule (#67) — a page refused to the check's own identity is not one that opened.
    `src/nav.py`'s pages come first, so the cap never leaves the menu out."""
    access = envs.PLATFORM_ACCESS or {}
    sso = envs.PLATFORM_AUTH == "sso"
    reader = _first(access.get("read")) or _first(access.get("write"))
    member = _identity(reader) if sso else {}
    rules = {name: _identity(_first(who), reader) for name, who in (access.get("rules") or {}).items() if who} if sso else {}
    try:
        from src.nav import PAGES  # pyright: ignore[reportMissingImports] — the app's own
    except ImportError:
        PAGES = []
    ruled = {p[1]: rules.get(p[2], member) for p in PAGES if len(p) > 2}
    # Into included routers too: FastAPI keeps one whole, so app.router.routes alone shows none of its
    # pages (the first live check opened only "/").
    paths = [p[1] for p in PAGES] + [p for p in _routes.gets(app) if not p.startswith(_SKIP)]
    return [(p, ruled.get(p, member)) for p in dict.fromkeys(paths)]


def _open(c: httpx.Client, path: str, headers: dict[str, str], until: float) -> int | str:
    """The status a page answers once its headers arrive — the body is never read, so a stream that
    never ends (SSE, a long poll) is judged by its status like any page, and closed."""
    try:
        with c.stream("GET", path, headers=headers, timeout=max(1.0, min(_PAGE, until - time.monotonic()))) as r:
            return r.status_code
    except httpx.HTTPError as e:
        return e.__class__.__name__


def _run(app, port: int) -> None:
    base = f"http://127.0.0.1:{port}"
    with httpx.Client(base_url=base, timeout=_PAGE, follow_redirects=False) as c:
        deadline = time.monotonic() + _WAIT
        while True:
            try:
                if c.get("/healthz").status_code < 500:
                    break
            except httpx.HTTPError:
                pass
            if time.monotonic() > deadline:
                log.warning("smoke", extra={"canvas_smoke": {"done": False, "why": "the app did not answer /healthz"}})
                return
            time.sleep(1)
        ok, failed, refused, left = 0, [], [], []
        visits = _visits(app)
        end = time.monotonic() + _TOTAL           # the summary is always logged, however slow a page is
        for n, (path, headers) in enumerate(visits):
            if n >= _MAX or time.monotonic() > end:
                left = [p for p, _ in visits[n:]]
                break
            status = _open(c, path, headers, end)
            log.info("smoke page", extra={"canvas_smoke_page": {"path": path, "status": status}})
            if status in (401, 403):
                refused.append([path, status])        # the check's own identity was turned away: not a page that opened
            elif isinstance(status, int) and status < 500:
                ok += 1
            else:
                failed.append([path, status])
        summary = {"done": True, "ok": ok, "failed": failed}
        if refused:
            summary["refused"] = refused
        if left:
            summary["unchecked"] = left
        log.info("smoke", extra={"canvas_smoke": summary})


def start(app, port: int | None = None) -> None:
    """Check the pages once, in the background, when the app is deployed — never on a laptop or in tests."""
    import os

    if not getattr(envs, "PLATFORM_PORTAL_URL", None) or os.environ.get("PLATFORM_SMOKE") == "0":
        return
    port = port or int(os.environ.get("PORT", "8080"))
    threading.Thread(target=_run, args=(app, port), name="canvas-smoke", daemon=True).start()
