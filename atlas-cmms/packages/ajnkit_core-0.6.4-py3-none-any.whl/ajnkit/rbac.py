"""App-side authorisation — who, among authenticated callers, may do what.

The split matters:

    AUTHENTICATION   the platform's. With `auth: sso` Authentik proves who the
                     caller is and adds X-authentik-email / -groups. Never
                     implement OIDC here — see ajnkit/identity.py.

    AUTHORISATION    the app's. Only this app knows that /admin is for two
                     groups. The platform cannot know your roles.

FAILS CLOSED, AND THIS IS THE POINT. Under `auth: none` there is no sign-in
in the request path, so **a caller can send X-authentik-groups themselves**.
Authorising on that would be bypassable while looking like it works — the worst
kind of security control. So every check below refuses unless
`envs.PLATFORM_AUTH == "sso"`.

Who may use the app at all is score.yaml's `access` (ajnkit/access.py, on every
request). This is for what is finer than that — a page for two groups — and
matches the same way: an entry with "@" is an email, anything else a group.

THE PEOPLE ARE WRITTEN IN score.yaml, THE CODE ONLY NAMES THE RULE:

    # score.yaml, beside auth: sso
    access:
      rules:
        dashboard: ["Finance", "ann@aljazeera.net"]

    @router.get("/dashboard")
    @require("dashboard")
    def dashboard(request): ...

The platform hands the rules to the app (PLATFORM_ACCESS, src/envs.py), so what is enforced is
what the portal shows on the app's page, and changing who may is a score.yaml change, not a code
change. `canvas validate` (and so `canvas deploy`) refuses a rule the code names and score.yaml does not declare.
`require(groups=[...])` still works, but nothing outside the code can see it.
"""

import inspect
from functools import wraps
from typing import Any

from fastapi import Request
from starlette.requests import HTTPConnection

from ajnkit.identity import Caller, caller, matches
from ajnkit.settings import envs

# The public API: what an app imports, and what this module's README documents.
__all__ = ["AuthNotEnabled", "Forbidden", "allowed", "permitted", "require", "rule"]


class Forbidden(Exception):
    """The caller is authenticated but not permitted."""


class AuthNotEnabled(Forbidden):
    """Authorisation was attempted while the route is `auth: none`, so identity
    headers are not trustworthy. Set auth: sso in score.yaml."""


def permitted(who: Caller, groups: list[str] | None = None, users: list[str] | None = None) -> bool:
    """True if `who` is in `groups` or `users`. Neither given == any signed-in caller."""
    if envs.PLATFORM_AUTH != "sso" or who.email is None:
        return False
    entries = [*(groups or []), *(users or [])]
    return not entries or matches(who, entries)


def rule(name: str) -> list[str] | None:
    """Who may, by score.yaml's access.rules.<name>; None when it declares no such rule."""
    return (envs.PLATFORM_ACCESS.get("rules") or {}).get(name)


def allowed(who: Caller, name: str) -> bool:
    """Whether `who` may, by the rule `name` — as @require decides, without ending the request: a
    chat's tools are offered by it (ajnkit/chat.py converse). A rule with nobody in it lets nobody in."""
    entries = rule(name)
    return envs.PLATFORM_AUTH == "sso" and who.email is not None and bool(entries) and matches(who, entries)


def require(
    name: str | None = None, *, groups: list[str] | None = None, users: list[str] | None = None
):
    """A rule, on a view or on a whole router.

        @router.get("/dashboard")
        @require("dashboard")              # who: score.yaml access.rules.dashboard
        def dashboard(request: Request): ...

        # one line covers the page, its htmx partials and its /api twin:
        router = APIRouter(prefix="/dashboard", dependencies=[Depends(require("dashboard"))])

    A view may be `def` or `async def`, and must take a `Request`. Raises AuthNotEnabled under
    `auth: none`, Forbidden otherwise; access.enforce answers both with a 403. Deployed with sign-in,
    a rule score.yaml does not declare stops the app at start (and `canvas deploy` before that).
    """
    if name is not None and (groups or users):
        raise TypeError(
            "@require(name) takes who from score.yaml; do not also pass groups or users"
        )
    if name is not None and envs.PLATFORM_AUTH == "sso" and rule(name) is None:
        raise RuntimeError(
            f"@require({name!r}): score.yaml declares no access.rules.{name} — add who may"
        )

    def check(request) -> None:
        if envs.PLATFORM_AUTH != "sso":
            raise AuthNotEnabled(
                "route is auth: none — identity headers are forgeable. "
                "Set auth: sso in score.yaml to authorise."
            )
        who = caller(request.headers)
        if name is None:
            if not permitted(who, groups=groups, users=users):
                raise Forbidden(f"{who.email or 'anonymous'} is not permitted")
        elif not allowed(who, name):          # what a chat's tools are offered by: one decision
            # A rule names its people; with none (not declared) nobody is let in, never everyone.
            raise Forbidden(f"{who.email or 'anonymous'} is not permitted" + ("" if rule(name) else f": no rule {name!r}"))

    return _Rule(check)


class _Rule:
    """What require() returns: a decorator when given a view, a dependency when FastAPI calls it
    with the request — so the same `require("…")` is written in both places, and `canvas deploy`
    finds every rule the code names."""

    def __init__(self, check):
        self._check = check

    def __call__(self, request: Request):
        if isinstance(request, HTTPConnection):
            self._check(request)                                  # as a dependency
            return None
        fn: Any = request     # a view: `request: Request` above is what FastAPI reads to pass one
        if inspect.iscoroutinefunction(fn):
            @wraps(fn)
            async def checked(*args, **kwargs):
                self._check(_request(fn, args, kwargs))
                return await fn(*args, **kwargs)
            return checked

        @wraps(fn)
        def view(*args, **kwargs):
            self._check(_request(fn, args, kwargs))
            return fn(*args, **kwargs)
        return view


def _request(fn, args, kwargs):
    """The view's request, whatever its parameter is called — the Request itself: a body the caller
    wrote can have a `headers` field too, and its identity would be theirs to choose."""
    for v in (*args, *kwargs.values()):
        if isinstance(v, HTTPConnection):
            return v
    raise TypeError(f"@require on {fn.__name__}: the view must take a `request: Request` parameter")
