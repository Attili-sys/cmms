"""Email — the `email` resource (score.yaml `notify: {type: email}`, ADR-38).

Plain text, sent by the platform under the app's name (its title) and in Canvas's own email layout, with replies going to the app's owner.
**The app's team only**, until a platform admin approves it for anyone (`canvas email request
"<why>"`), and **20 recipients an hour** either way — so tell people something worth reading, not
every event. Anything not sent raises `EmailRefused` with the reason, a lost connection or a
timeout included; let a request fail with it rather than retrying.

On your computer there is no token: the message is checked as the platform would check it, then
written to the log instead of sent. The settings are read from the environment here, not from
src/envs.py, so an app updated from before email has all it needs (issue #67).
"""

import os
import re

import httpx

from ajnkit.logger import log

# The public API: what an app imports, and what this module's README documents.
__all__ = ["EmailRefused", "send"]

# What the platform takes — its site contract's `limits.email`, which a test in the canvas CLI holds
# these to: checked here too, so a run on your computer refuses what the platform would.
# The contract's (limits.email.address): no space, no control character, nothing that would end or
# split an address.
_ADDRESS = re.compile(r"^[^@\s\x00-\x1f\x7f<>,;\"]+@[^@\s\x00-\x1f\x7f<>,;\"]+\.[^@\s\x00-\x1f\x7f<>,;\"]+$")
LIMIT, ADDRESS_MAX, SUBJECT_MAX, TEXT_MAX = 20, 254, 200, 65536
# Longer than the platform takes to give up on the mail relay, so its answer — sent or not — always
# arrives before this does (issue #66).
TIMEOUT = httpx.Timeout(30.0, connect=5.0)


class EmailRefused(Exception):
    """Not sent: outside the team, over the hour's limit, or the platform could not."""


def _client() -> httpx.Client:
    """ajnkit/http.py's rule — never without a timeout — with email's own, longer one."""
    return httpx.Client(timeout=TIMEOUT)


def _check(to: list[str], subject: str, text: str) -> None:
    if not isinstance(to, list) or not 1 <= len(to) <= LIMIT:
        raise EmailRefused(f"`to` is a list of 1 to {LIMIT} addresses")
    if bad := [a for a in to if not isinstance(a, str) or len(a) > ADDRESS_MAX or not _ADDRESS.fullmatch(a)]:
        raise EmailRefused(f"not an email address: {', '.join(map(str, bad))}")
    if not isinstance(subject, str) or not 1 <= len(subject) <= SUBJECT_MAX or "\n" in subject or "\r" in subject:
        raise EmailRefused(f"the subject is one line of text, 1 to {SUBJECT_MAX} characters")
    # Characters, as the platform counts them (its Email model's max_length).
    if not isinstance(text, str) or not 1 <= len(text) <= TEXT_MAX:
        raise EmailRefused(f"the text is text, 1 to {TEXT_MAX:,} characters")


def _reason(r: httpx.Response) -> str:
    """The platform's reason in one line: its `detail`, a validation list as what each field must
    be, or — from a proxy in front of it — what kind of answer came back."""
    try:
        detail = r.json().get("detail")
    except (ValueError, AttributeError):
        detail = None
    if isinstance(detail, str):
        return detail
    if isinstance(detail, list):
        return "; ".join(f"{(d.get('loc') or ['?'])[-1]}: {d.get('msg', d)}" if isinstance(d, dict) else str(d)
                         for d in detail)
    # From a proxy in front of the platform: 503, it never got there; 502 and 504, it may have (#77).
    if r.status_code == 503:
        return "the platform could not be reached — nothing was sent"
    if r.status_code in (502, 504):
        return "no answer from the platform — it may or may not have been sent; do not send it again"
    return f"an answer the platform does not give: {r.text[:120]!r}"


def send(to: list[str], subject: str, text: str) -> int:
    """Send one message; returns how many more recipients the app may write to this hour."""
    _check(to, subject, text)
    url, token = os.environ.get("PLATFORM_EMAIL_URL"), os.environ.get("PLATFORM_EMAIL_TOKEN")
    if not token:
        if os.environ.get("PLATFORM_PORTAL_URL"):     # set by the platform: this is deployed
            raise EmailRefused("this app has no email resource — add `notify: {type: email}` under "
                               "resources in score.yaml, then deploy")
        log.info("email (not sent, running locally) to=%s subject=%s\n%s", ", ".join(to), subject, text)
        return LIMIT
    if not url:
        raise EmailRefused("PLATFORM_EMAIL_URL is not set — redeploy the app")
    try:
        with _client() as c:
            r = c.post(url, json={"to": to, "subject": subject, "text": text},
                       headers={"Authorization": f"Bearer {token}"})
    # By whether the message left: not connected, nothing was sent; sent and no answer — a timeout
    # reading, a dropped connection — it may have gone out, and must not be sent twice (#77).
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout) as e:
        raise EmailRefused(f"the platform could not be reached ({type(e).__name__}) — nothing was sent") from None
    except httpx.HTTPError as e:
        raise EmailRefused(f"no answer from the platform ({type(e).__name__}) — it may or may not have been "
                           f"sent; do not send it again") from None
    if r.status_code != 200:
        raise EmailRefused(f"{r.status_code}: {_reason(r)}")
    try:
        return int(r.json()["left"])
    except (ValueError, KeyError, TypeError):
        return 0                                # sent; how much of the hour is left is unknown
