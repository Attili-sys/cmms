---
name: ajnkit-email
description: >-
  Reference for the platform's email — ajnkit-email (Python, `from ajnkit.email import send`) or
  @ajnkit/email (Next.js, `send` from `@ajnkit/email`). Use when writing code that sends an
  email or handles EmailRefused. Setting email up, and who it may go to, is request-email.
---

```python
from ajnkit.email import EmailRefused, send

try:
    left = send(["sahar@aljazeera.net"], "The rota for next week", body)   # how many more this hour
except EmailRefused as e:
    return {"error": str(e)}                                              # a sentence for the person
```
```ts
import { EmailRefused, send } from "@ajnkit/email";
const left = await send(["sahar@aljazeera.net"], "The rota for next week", body);
```

| | |
|---|---|
| To | the app's team only; anyone else after an admin approves (`canvas email request "<why>"`) |
| Limits | 20 recipients an hour, a 254-character address, a 200-character subject, 65,536 characters of plain text |
| Look | Canvas's layout, under the app's name — no HTML of the app's own |
| On your computer | checked, then logged — not sent |

`EmailRefused` is a sentence for the person: show it, log it, and act on what it says —

| It says | Do |
|---|---|
| the input is wrong | fix it, or tell the person what to change |
| `403: email.recipient` — outside the team, and the app is not approved | check the address; outside on purpose is `canvas email request` (request-email) |
| `429: email.limit` — 20 recipients this hour; it says when there is room | send less — a digest — never retry in a loop |
| `401` | the token is not this app's (taken down and deployed again): `canvas deploy` |
| "nothing was sent" | may be tried once more, later, from background work (`add-job`) |
| "may or may not have been sent; do not send it again" (502, 504, a timeout) | **never resend** — record it as unknown |
| "no email resource" | `notify: {type: email}` is missing from score.yaml (request-email) |

`send` blocks up to 30 s: Python, from a plain `def` route. Never SMTP, a password or a mail SDK.
In a test, replace `send` where the app imports it (`monkeypatch.setattr(notify, "send", fake)`,
`vi.mock("@ajnkit/email", …)`) — not the settings, which it reads from the environment.
