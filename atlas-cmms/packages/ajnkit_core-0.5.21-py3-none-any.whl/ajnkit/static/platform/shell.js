// The page shell's behaviour, from a file: the platform's Content-Security-Policy runs no inline script.
// THE PLATFORM'S (`canvas app update` replaces it). Loaded once, in <head>: hx-boost swaps only the
// body, so these listeners are added once, and the theme button is set again after each swap.
//
// A menu closes on Escape, and when you click outside it. The theme button flips it at once and keeps
// the choice for a year, for every app on the platform (<app>--<team>.<base> share the base's cookie)
// — or forgets it when flipped back to what the OS says, so the page follows the OS again. A dialog
// opens from a button with data-dialog-open="<its id>", and closes from one with data-dialog-close —
// in place of an onclick, which the policy refuses.
//
// A large file_input (data-large) is sent before its form, in pieces, to the platform's
// /media/uploads (ajnkit.media): a piece that does not arrive is sent again, from where the
// app says the file stands; the form then carries the kept file's name in place of the file.
//
// Framed — and only the portal may frame an app (origin.framer) — the page tells the frame's parent it
// showed, so Canvas Studio's preview offers "open it in a new tab" only when the app did not show.
(() => {
  if (window.parent !== window) window.parent.postMessage({ ajnkit: "shown" }, "*");
  const PIECE_TRIES = 5;
  const json = async (r) => { try { return await r.json(); } catch { return {}; } };

  async function sendLarge(file, said) {
    const start = await fetch("/media/uploads", {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ size: file.size }),
    });
    const begun = await json(start);
    if (start.status === 404) throw new Error("This app does not take large files yet: src/app.py needs app.include_router(media.router).");
    if (!start.ok) throw new Error(begun.error || "The upload could not start.");
    let offset = 0, tries = 0;
    for (;;) {
      said(Math.floor((offset / file.size) * 100));
      let r;
      try {
        r = await fetch("/media/uploads/" + begun.id, {
          method: "PUT", headers: { "upload-offset": String(offset) }, body: file.slice(offset, offset + begun.piece),
        });
      } catch { r = null; }                                            // the connection dropped
      const a = r ? await json(r) : {};
      if (r && r.ok && a.name) return a.name;
      if (r && r.ok) { offset = a.offset; tries = 0; continue; }
      if (r && r.status === 400) throw new Error(a.error || "The file was refused.");
      // A whole file still answers with its name: no such upload stays so, however often it is sent.
      if (r && r.status === 404) throw new Error("The upload was lost — send the file again.");
      if (++tries > PIECE_TRIES) throw new Error("The upload kept failing — check the connection and send it again.");
      await new Promise((ok) => setTimeout(ok, 1000 * tries));
      const at = await fetch("/media/uploads/" + begun.id).then(json, () => ({}));   // where it stands now
      if (Number.isInteger(at.offset)) offset = at.offset;
    }
  }

  document.addEventListener("submit", async (e) => {
    const form = e.target, large = [...form.querySelectorAll("input[type=file][data-large]")].filter((i) => i.files.length);
    if (!large.length || form.dataset.sending) return;
    e.preventDefault();
    e.stopImmediatePropagation();                                      // before hx-boost posts it
    form.dataset.sending = "1";
    try {
      for (const input of large) {
        const note = document.getElementById(input.id + "-sent");
        const say = (text) => { if (note) { note.hidden = false; note.textContent = text; } };
        const names = [];
        for (const file of input.files) names.push(await sendLarge(file, (pct) => say("Sending " + file.name + " — " + pct + "%")));
        say("Sent");
        for (const name of names) {
          const kept = document.createElement("input");
          Object.assign(kept, { type: "hidden", name: input.name, value: name });
          form.append(kept);
        }
        input.disabled = true;                                         // the file itself is not posted again
      }
      form.requestSubmit();                                            // dispatched now: this handler lets it pass
      delete form.dataset.sending;
    } catch (err) {
      const note = document.getElementById(large[0].id + "-sent");
      if (note) { note.hidden = false; note.textContent = err.message; }
      delete form.dataset.sending;
    }
  }, true);

  const close = (keep) => document.querySelectorAll("[data-shell-menu][open]").forEach((d) => { if (d !== keep) d.open = false; });
  const os = matchMedia("(prefers-color-scheme: dark)");
  const current = () => document.documentElement.dataset.theme || (os.matches ? "dark" : "light");
  const show = () => document.querySelectorAll("[data-theme-toggle]").forEach((t) => {
    t.hidden = false;
    t.setAttribute("aria-pressed", current() === "dark");
  });

  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  document.addEventListener("click", (e) => {
    close(e.target.closest("[data-shell-menu]"));

    const opens = e.target.closest("[data-dialog-open]");
    if (opens) document.getElementById(opens.dataset.dialogOpen)?.showModal();
    if (e.target.closest("[data-dialog-close]")) e.target.closest("dialog")?.close();

    if (!e.target.closest("[data-theme-toggle]")) return;
    const root = document.documentElement;
    const next = current() === "dark" ? "light" : "dark", theme = next === (os.matches ? "dark" : "light") ? "" : next;
    const host = location.hostname, domain = host.split(".")[0].includes("--") ? "; domain=" + host.slice(host.indexOf(".") + 1) : "";
    document.cookie = "theme=" + theme + "; path=/; max-age=" + (theme ? 31536000 : 0) + "; samesite=lax" + domain + (location.protocol === "https:" ? "; secure" : "");
    if (theme) root.dataset.theme = theme; else delete root.dataset.theme;
    document.querySelector('meta[name="color-scheme"]').content = theme || "light dark";
    show();
  });
  os.addEventListener("change", show);
  document.addEventListener("htmx:afterSettle", show);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", show); else show();
})();
