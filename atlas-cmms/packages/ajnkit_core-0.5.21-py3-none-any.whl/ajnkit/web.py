"""The pages' templates — one `templates` for every view — and what each page's shell needs.

THE PLATFORM'S (ajnkit; `canvas app update` brings the next version). Every page extends `base.html`, which extends
`platform/shell.html`: the header (the app's title, its pages, who is signed in and Sign out) and the
footer are drawn there, once, for every app. A page draws only its own content, from the components
in `platform/ui.html` (listed in `platform/COMPONENTS.md`).

    from ajnkit.web import templates
    return templates.TemplateResponse(request, "orders.html", {"orders": orders})
"""

import hashlib
import html
from functools import cache
from pathlib import Path
from urllib.parse import quote

import src  # pyright: ignore[reportMissingImports] — the app's own package: there in every app, never here
import yaml
from fastapi.templating import Jinja2Templates
from starlette.staticfiles import PathLike

import ajnkit
from ajnkit.identity import caller
from ajnkit.rbac import allowed
from ajnkit.settings import envs

_ROOT = Path(src.__path__[0]).resolve().parent

# The public API: what an app imports, and what this module's README documents.
__all__ = ["about", "asset", "favicon", "has", "initials", "missing", "pages", "platform", "templates"]

# The platform's own: the page shell and the components (templates/platform/), and their styles and
# scripts (static/platform/) — in the packages, never in the app. The core's own folder:
_HERE = Path(__file__).resolve().parent
# Every installed ajnkit package's own
# folder: one when installed from wheels (they unpack into one `ajnkit`), several in sdk/'s workspace.
# The chat's script is ajnkit-chat's, the shell's ajnkit-core's.
_PACKAGES = [Path(p) for p in ajnkit.__path__]

# Resolved from the app's package, never the working directory: buildpacks start the process from
# /workspace, `uv run` from the app's folder, and a test runner from wherever pytest was invoked.
# The app's templates first: base.html and its pages; `platform/shell.html` and `platform/ui.html` here.
templates = Jinja2Templates(directory=[_ROOT / "src" / "templates", *(p / "templates" for p in _PACKAGES)])


@cache
def about() -> dict[str, str]:
    """The app's title, description and icon, from its own score.yaml's metadata.annotations
    (canvas.dev/title, /description, /icon; metadata.name when it has no title). Read as YAML, as the
    platform reads it (safe_load: `"Q&A #1"`, `'It''s here'` and flow style are what they say); a
    value that is not text is not used, and a score.yaml that cannot be read gives none — a page is
    never stopped by it. The icon is its URL — `canvas validate` keeps pictures under src/static/,
    which the app serves at /static/."""
    try:
        score = yaml.safe_load((_ROOT / "score.yaml").read_text())
    except (OSError, UnicodeDecodeError, yaml.YAMLError):
        score = None
    def table(value) -> dict:
        return value if isinstance(value, dict) else {}

    meta = table(table(score).get("metadata"))
    notes = table(meta.get("annotations"))

    def text(value) -> str:
        return value.strip() if isinstance(value, str) else ""

    icon = text(notes.get("canvas.dev/icon"))
    return {"title": text(notes.get("canvas.dev/title")) or text(meta.get("name")),
            "description": text(notes.get("canvas.dev/description")),
            "icon": "/static/" + icon.removeprefix("src/static/") if icon.startswith("src/static/") else ""}


@cache
def asset(path: str) -> str:
    """A file under src/static/ by a URL that changes when the file does, so a browser never keeps
    an old copy (issue #32). Read once per process: an image's files do not change while it runs."""
    for where in (_ROOT / "src" / "static" / path, *(p / "static" / path for p in _PACKAGES)):
        try:
            return f"/static/{path}?v={hashlib.sha256(where.read_bytes()).hexdigest()[:10]}"
        except OSError:
            continue
    return f"/static/{path}"


def pages(request=None) -> list[tuple[str, str]]:
    """The app's pages, in order — `src/nav.py`, the app's own. Navigation shows from two. A page with a
    third item, a rule — ("Questions", "/questions", "admin") — is in the menu only of who that rule lets
    in (score.yaml access.rules, as @require decides): each role sees its own pages."""
    try:
        from src.nav import PAGES  # pyright: ignore[reportMissingImports] — the app's own
    except ImportError:          # an app made before src/nav.py
        return [("Home", "/")]
    who = caller(request.headers) if request is not None else None
    return [(p[0], p[1]) for p in PAGES if len(p) < 3 or (who is not None and allowed(who, p[2]))]


def initials(name: str | None) -> str:
    return "".join(w[0] for w in (name or "").split()[:2]).upper() or "?"


def favicon() -> str:
    """The tab's icon: the app's own (score.yaml canvas.dev/icon), else its initial in white on the house
    teal — the header's mark — drawn inline, so there is no file to forget."""
    app = about()
    if app["icon"]:
        return app["icon"]
    letter = html.escape((app["title"] or "·")[:1].upper())
    svg = ("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><rect width='64' height='64' rx='14' "
           "fill='#1B4A4E'/><text x='32' y='44' text-anchor='middle' font-family='system-ui,sans-serif' "
           f"font-size='36' font-weight='600' fill='#fff'>{letter}</text></svg>")
    return "data:image/svg+xml," + quote(svg)


def has(path: str) -> bool:
    """A platform file is here — a feature's (ajnkit-chat's chat.js) only when the app has that package."""
    return any((p / "static" / path).is_file() for p in _PACKAGES)


templates.env.globals.update(
    has=has,
    about=about,
    favicon=favicon,
    asset=asset,
    pages=pages,
    me=lambda request: caller(request.headers),
    # From the platform (the app chart): absent on your computer, so Sign out is not shown there.
    sign_out_url=getattr(envs, "PLATFORM_SIGN_OUT_URL", None),
    portal_url=getattr(envs, "PLATFORM_PORTAL_URL", None),
)
templates.env.filters["initials"] = initials


# The packages an app adds by a feature's skill (sdk/packages.json's `features`), each its own module.
FEATURES = ("llm", "chat", "media", "email")


def missing(e: ImportError) -> None:
    """An import of a feature's module whose package the app has not got (`from ajnkit import chat`,
    `from ajnkit.chat import stream`) raised again as what to run — `canvas app add chat`; any other
    left to its caller. run.py and tests/conftest.py — the platform's — call it around their import
    of the app."""
    name = e.name or ""
    if name.startswith("ajnkit."):
        module = name.removeprefix("ajnkit.")
    else:      # `from ajnkit import chat`: Python names the package, and the module in name_from (3.12)
        module = getattr(e, "name_from", None) if name == "ajnkit" else None
    if module in FEATURES:
        from importlib.util import find_spec

        if find_spec(f"ajnkit.{module}") is None:
            raise ModuleNotFoundError(f"ajnkit-{module} is not installed — `canvas app add {module}`",
                                      name=f"ajnkit.{module}") from e


def platform(app) -> None:
    """What every app is served with, whatever its src/app.py has: the platform's styles and scripts
    at /static/platform/ (from every ajnkit package installed), its large uploads when ajnkit-media is
    one of them, and score.yaml's access with the security headers on every request (ajnkit.access) —
    and no WebSocket, which the platform does not provision, and a 422 that never echoes the input.
    run.py and tests/conftest.py — the platform's — call it before the app answers anything; each is
    added only when the app has not added it itself."""
    from importlib.util import find_spec

    from fastapi.exception_handlers import request_validation_exception_handler
    from fastapi.exceptions import RequestValidationError
    from fastapi.staticfiles import StaticFiles
    from starlette.routing import Mount

    from ajnkit import access

    if not any(isinstance(r, Mount) and r.path == "/static/platform" for r in app.router.routes):
        class Platform(StaticFiles):
            """/static/platform/ from every installed ajnkit package's folder: the core's and a feature's."""

            def get_directories(self, directory: PathLike | None = None,
                                packages: list[str | tuple[str, str]] | None = None) -> list[PathLike]:
                return [d for p in _PACKAGES if (d := p / "static" / "platform").is_dir()]

        files = Platform()
        # First, so the app's own /static mount does not answer for the platform's files.
        app.router.routes.insert(0, Mount("/static/platform", app=files, name="platform"))
    if find_spec("ajnkit.media"):
        from ajnkit import media

        # Included as the router itself (FastAPI keeps it whole now) or, before, as copies of its routes.
        ours = {getattr(r, "endpoint", None) for r in media.router.routes}
        if not any(getattr(r, "original_router", None) is media.router or getattr(r, "endpoint", None) in ours
                   for r in app.router.routes):
            app.include_router(media.router)
    if not any(m.kwargs.get("dispatch") is access.enforce for m in app.user_middleware):
        app.middleware("http")(access.enforce)
    if not any(m.cls is access.NoSockets for m in app.user_middleware):
        app.add_middleware(access.NoSockets)
    # A 422 that names what was wrong and never writes the input back (#120) — unless the app has its own.
    if app.exception_handlers.get(RequestValidationError) in (None, request_validation_exception_handler):
        app.add_exception_handler(RequestValidationError, access.invalid)
    # Deployed, the app opens its own pages once it is up and logs whether each opened (ajnkit.smoke):
    # a pod can pass /healthz while every page fails. Once per process, whoever calls platform().
    from ajnkit import smoke

    if not getattr(app.state, "canvas_smoke", False):
        app.state.canvas_smoke = True
        smoke.start(app)
